package com.lab2;

public class Test {

	public static void main(String[] args) {
		CellPhone cp1 = new CellPhone();
		cp1.setScreenSize("5.8-inch Super Retina XDR OLED");
		cp1.setOs("iOS 13");
		cp1.setStorage(512);
		cp1.setProcessor("Apple A13 Bionic");
		cp1.setRam(4);
		cp1.setCamera("12-megapixel, 12MP telephoto, and 12MP ultrawide, 12MP front");
		cp1.setBluetooth(5);
		cp1.setPorts("Lightning");
		cp1.setBattery("4,000mAH");
		cp1.setColor("Midnight Green, Space Grey, Silver, Gold");
		System.out.println("Sample Phone 1 Specifications");
		System.out.println("Screen size: " + cp1.getScreenSize());
		System.out.println("Operating system: " + cp1.getOs());
		System.out.println("Storage: " + cp1.getStorage() + "GB");
		System.out.println("Processor: " + cp1.getProcessor());
		System.out.println("RAM: " + cp1.getRam() + "GB");
		System.out.println("Camera: " + cp1.getCamera());
		System.out.println("Bluetooth version: " + cp1.getBluetooth());
		System.out.println("Ports: " + cp1.getPorts());
		System.out.println("Battery: " + cp1.getBattery());
		System.out.println("Colors: " + cp1.getColor());	
			
		CellPhone cp2 = new CellPhone();
		cp2.setScreenSize("6.2-inch Dynamic AMOLED");
		cp2.setOs("Android 10");
		cp2.setStorage(128);
		cp2.setProcessor("	Qualcomm Snapdragon 865");
		cp2.setRam(12);
		cp2.setCamera("12-megapixel, 64MP telephoto, and 12MP ultrawide rear, 10MP front");
		cp2.setBluetooth(5);
		cp2.setPorts("USB-C");
		cp2.setBattery("4,000mAh, Fast charging (25W) + Qi wireless charging");
		cp2.setColor("Cosmic Gray, Cloud Blue, Cloud Pink");
		System.out.println("Sample Phone 2 Specifications");
		System.out.println("Screen size: " + cp2.getScreenSize());
		System.out.println("Operating system: " + cp2.getOs());
		System.out.println("Storage: " + cp2.getStorage() + "GB");
		System.out.println("Processor: " + cp2.getProcessor());
		System.out.println("RAM: " + cp2.getRam() + "GB");
		System.out.println("Camera: " + cp1.getCamera());
		System.out.println("Bluetooth version: " + cp2.getBluetooth());
		System.out.println("Ports: " + cp2.getPorts());
		System.out.println("Battery: " + cp1.getBattery());
		System.out.println("Colors: " + cp2.getColor());	
			
		HighEnd he2 = new HighEnd();
		System.out.println(he2.add(1000, 600, 10, 1));
	}

}
