package com.lab2;

public class HighEnd extends CellPhone{
	private String fingerprintSensor;
	private String waterResistance;
	
	public HighEnd() {
		
	}
	
	public HighEnd(String screenSize, String os, int storage, String processor, int ram, String camera, float bluetooth, String ports, String battery, String color, String fingerprintSensor, String waterResistance){
		super(screenSize, os, storage, processor, ram, camera, bluetooth, ports, battery, color);
		this.fingerprintSensor = fingerprintSensor;
		this.waterResistance = waterResistance;
	}
	
	public void setFingerprintSensor (String fingerprintSensor) {
		this.fingerprintSensor = fingerprintSensor;
	}
		
	public void setWaterResistance (String waterResistance) {
		this.waterResistance = waterResistance;
	}
	
	public String getfingerprintSensor() {
		return this.fingerprintSensor;
	}
	
	public String getwaterResistance() {
		return this.waterResistance;
	}
	
	public void fastBrowse(String website) {
		System.out.println("Loading " + website + " ...");
	}
	
	public void highCost(int price) {
		System.out.println("Total cost is " + price + " ...");
	}	
	
	public int add(int ... a) {
		int sum = 0;
		for(int num : a) {
			sum += num;
		}
		return sum;
	}
	
}
	
	


