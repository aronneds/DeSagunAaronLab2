package com.lab2;

public class CellPhone {
	private String screenSize;
	private String os;
	private int storage;
	private String processor;
	private int ram;
	private String camera;
	private float bluetooth;
	private String ports;
	private String battery;
	private String color;

	public CellPhone() {
		
	}
	
	public CellPhone(String screenSize, String os, int storage, String processor, int ram,String camera, float bluetooth, String ports, String battery,String color) {
		this.screenSize = screenSize;
		this.os = os;
		this.storage = storage;
		this.processor = processor;
		this.ram = ram;
		this.camera = camera;
		this.bluetooth = bluetooth;
		this.ports = ports;
		this.battery = battery;
		this.color = color;
	}// Sir, is this the same as the codes below (setters)?
	
	public void setScreenSize(String screenSize) {
		this.screenSize = screenSize;
		}

	public void setOs(String os) {
		this.os = os;
		}
	
	public void setStorage(int storage) {
		this.storage = storage;
		}
	
	public void setProcessor(String processor) {
		this.processor = processor;
		}

	public void setRam(int ram) {
		this.ram = ram;
	}
	
	public void setCamera(String camera) {
		this.camera = camera;
	}
	
	public void setBluetooth(float bluetooth) {
		this.bluetooth = bluetooth;
	}

	public void setPorts(String ports) {
		this.ports = ports;
	}

	public void setBattery(String battery) {
		this.battery = battery;
	}

	public void setColor(String color) {
		this.color = color;
	}
	
	public String getScreenSize() {
		return this.screenSize;
		}

	public String getOs() {
		return this.os;
		}

	public int getStorage() {
		return this.storage;
		}

	public String getProcessor() {
		return this.processor;
		}

	public int getRam() {
		return this.ram;
		}

	public String getCamera() {
		return this.camera;
		}

	public double getBluetooth() {
		return this.bluetooth;
		}

	public String getPorts() {
		return this.ports;
		}

	public String getBattery() {
		return this.battery;
		}

	public String getColor() {
		return this.color;
		}
	
	public void call(String person) {
		System.out.println("Calling " + person + " ...");
	}
	
}
